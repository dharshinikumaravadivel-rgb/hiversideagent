# Hiver SDE Intern — Evaluation Report

## 1. Problem framing
Brand: TODO

A good agent should classify customer issues, draft historically grounded replies, and make an auditable escalation decision.

### What we chose not to build
- Live Twitter integration
- Production customer/account integration
- Real refund/payment execution
- Multi-brand support
- Autonomous account changes

## 2. Dataset and sampling
TODO

## 3. Intent taxonomy
TODO

## 4. Results vs baselines
| System | Accuracy | Macro F1 |
|---|---:|---:|
| Majority baseline | TODO | TODO |
| TF-IDF + Logistic Regression | TODO | TODO |
| AI support agent | TODO | TODO |

Reply groundedness: TODO  
Reply helpfulness: TODO  
Escalation F1: TODO

## 5. LLM-as-a-judge validation
TODO — compare judge ratings with human ratings.

## 6. Top 5 failure modes
1. TODO
2. TODO
3. TODO
4. TODO
5. TODO

## 7. What is misleading about my headline number?
Overall accuracy alone does not prove reply quality, grounding, or correct escalation. Discuss class imbalance, difficult cases, and the difference between intent correctness and end-to-end support quality.

## 8. What I would do with one more week
- Improve taxonomy from confusion analysis.
- Improve retrieval.
- Add multi-intent handling.
- Calibrate escalation thresholds.
- Expand human evaluation.
