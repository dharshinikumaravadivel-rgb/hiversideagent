import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score

df = pd.read_csv("evaluation/golden_set.csv").dropna(subset=["text", "gold_intent"])

if len(df) < 20:
    print("Add 150–250 hand-labelled examples to golden_set.csv.")
else:
    xtr, xte, ytr, yte = train_test_split(
        df.text, df.gold_intent, test_size=0.25,
        random_state=42, stratify=df.gold_intent
    )
    vec = TfidfVectorizer(ngram_range=(1, 2))
    model = LogisticRegression(max_iter=1000)
    model.fit(vec.fit_transform(xtr), ytr)
    pred = model.predict(vec.transform(xte))
    print("TF-IDF + Logistic Regression")
    print("Accuracy:", accuracy_score(yte, pred))
    print("Macro F1:", f1_score(yte, pred, average="macro"))
