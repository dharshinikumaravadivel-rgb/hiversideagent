JUDGE_RUBRIC = {
    "groundedness": "1–5: Is the reply supported by the retrieved historical evidence?",
    "helpfulness": "1–5: Does it address the customer's problem?",
    "relevance": "1–5: Is it concise and directly relevant?",
    "hallucination": "1–5: Does it avoid unsupported claims?",
}

print(JUDGE_RUBRIC)
