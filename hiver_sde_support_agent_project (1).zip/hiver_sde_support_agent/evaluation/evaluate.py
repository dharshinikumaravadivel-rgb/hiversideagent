import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, classification_report

path = "evaluation/predictions.csv"
df = pd.read_csv(path)

print("Intent accuracy:", accuracy_score(df.gold_intent, df.pred_intent))
print("Intent macro F1:", f1_score(df.gold_intent, df.pred_intent, average="macro"))
print(classification_report(df.gold_intent, df.pred_intent))

if {"gold_escalation", "pred_escalation"} <= set(df.columns):
    print("Escalation macro F1:",
          f1_score(df.gold_escalation, df.pred_escalation, average="macro"))
