BRAND_NAME = "CHANGE_ME"

INTENTS = [
    "refund",
    "cancellation",
    "delay",
    "booking",
    "payment",
    "account",
    "service_issue",
    "other",
]

TOP_K = 5
GOLDEN_SET_SIZE = 200
