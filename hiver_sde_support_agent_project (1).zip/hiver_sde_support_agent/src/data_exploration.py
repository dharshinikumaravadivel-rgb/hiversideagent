from pathlib import Path
import pandas as pd

def main():
    files = list(Path("data/raw").glob("*.csv"))
    if not files:
        print("Put the Kaggle CSV in data/raw/ first.")
        return
    df = pd.read_csv(files[0])
    print("Shape:", df.shape)
    print("\nColumns:")
    print(list(df.columns))
    print("\nFirst 5 rows:")
    print(df.head().to_string())

if __name__ == "__main__":
    main()
