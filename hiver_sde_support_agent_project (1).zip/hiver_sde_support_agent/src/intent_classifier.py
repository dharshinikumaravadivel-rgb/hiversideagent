from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

class IntentClassifier:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
        self.model = LogisticRegression(max_iter=1000)

    def fit(self, texts, labels):
        self.model.fit(self.vectorizer.fit_transform(texts), labels)
        return self

    def predict(self, texts):
        return self.model.predict(self.vectorizer.transform(texts))
