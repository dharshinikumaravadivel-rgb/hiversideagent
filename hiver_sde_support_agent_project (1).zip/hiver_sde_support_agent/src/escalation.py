def decide_escalation(message, intent, confidence=None):
    if intent in {"refund", "payment", "account"}:
        return "ESCALATE", "This type of case may require account-specific verification."
    if confidence is not None and confidence < 0.65:
        return "ESCALATE", "Classifier confidence is below the configured threshold."
    return "AUTO-HANDLE", "The request appears suitable for a standard support response."
