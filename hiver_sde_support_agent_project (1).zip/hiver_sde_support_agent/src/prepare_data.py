from pathlib import Path
import pandas as pd
from config import BRAND_NAME

def main():
    if BRAND_NAME == "CHANGE_ME":
        raise ValueError("Update BRAND_NAME in config.py after exploration.")

    files = list(Path("data/raw").glob("*.csv"))
    if not files:
        raise FileNotFoundError("Put the Kaggle CSV in data/raw/.")

    df = pd.read_csv(files[0])

    text_candidates = ["text", "tweet", "message", "content", "body"]
    text_col = next((c for c in text_candidates if c in df.columns), None)
    if text_col is None:
        raise ValueError("Text column not detected. Inspect columns and update this file.")

    print("Detected text column:", text_col)
    print("Brand filtering depends on the exact dataset schema; update this file after inspection.")

if __name__ == "__main__":
    main()
