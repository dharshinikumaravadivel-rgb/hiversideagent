import os
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

SYSTEM = """You are a customer-support drafting assistant.
Use historical examples as evidence.
Do not invent policies, prices, timelines, refunds, guarantees, or actions.
If evidence is insufficient, say that human review is needed.
Return only the draft reply."""

def generate_reply(customer_message, intent, examples):
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    evidence = "\n".join(
        f"Historical example {i+1}: {text}" for i, (text, _) in enumerate(examples)
    )
    prompt = f"""Customer message:
{customer_message}

Predicted intent:
{intent}

Historical evidence:
{evidence}
"""
    result = client.chat.completions.create(
        model=os.getenv("MODEL_NAME", "gpt-4o-mini"),
        messages=[
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": prompt},
        ],
        temperature=0.1,
    )
    return result.choices[0].message.content.strip()
