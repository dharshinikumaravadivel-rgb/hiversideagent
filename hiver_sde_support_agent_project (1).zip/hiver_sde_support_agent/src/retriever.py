import numpy as np
from sentence_transformers import SentenceTransformer

class Retriever:
    def __init__(self, texts):
        self.texts = list(texts)
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
        self.embeddings = self.model.encode(self.texts, normalize_embeddings=True)

    def search(self, query, k=5):
        q = self.model.encode([query], normalize_embeddings=True)[0]
        scores = self.embeddings @ q
        ids = np.argsort(-scores)[:k]
        return [(self.texts[i], float(scores[i])) for i in ids]
