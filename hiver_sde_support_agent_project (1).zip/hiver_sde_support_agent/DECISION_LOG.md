# Decision Log

1. One brand instead of all brands — controls domain variation.
2. Intents derived from brand data — follows the assignment.
3. 5–8 intents — keeps the taxonomy manageable.
4. 200-example golden set — within the required range.
5. Macro F1 — handles class imbalance better than accuracy alone.
6. Majority baseline — trivial reference point.
7. TF-IDF + Logistic Regression — simple reproducible ML baseline.
8. Semantic retrieval — finds similar historical cases.
9. Historical evidence in generation — reduces unsupported responses.
10. Explicit escalation reason — makes decisions auditable.
11. Conservative handling of account-specific cases — agent cannot verify private data.
12. Human validation of LLM judge — measures judge reliability.
13. Dataset excluded from GitHub — avoids committing large third-party data.
14. Fixed random seed — improves reproducibility.
15. Limitations reported with headline metrics — avoids overclaiming.
