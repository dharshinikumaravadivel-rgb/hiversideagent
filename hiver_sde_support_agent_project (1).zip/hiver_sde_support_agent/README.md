# Hiver SDE Intern — AI Customer Support Agent

A runnable starter repository for the Hiver SDE Intern take-home assignment.

## Pipeline
Dataset → brand selection → intent taxonomy → baselines → retrieval → reply generation → escalation → evaluation.

## Setup
```bash
pip install -r requirements.txt
copy .env.example .env
```

Put the Kaggle Customer Support on Twitter CSV inside `data/raw/`.

Run:
```bash
python src/data_exploration.py
```
Then update `config.py` with the selected brand and run the remaining pipeline.

The Kaggle dataset is intentionally NOT included in this repository. Do not commit it to GitHub.
